# Changes

## 1.5.0, November 2026

How it works
- The page is now two columns on wide screens: the story on the left, the mathematics on the right.
- Left: a new business model section (who pays, for what, how it is priced, what it costs) joins the problem, solution, audience, novelty, market and revenue sections.
- Right: fourteen numbered formulas, each the one the code evaluates, with a link to the page that uses it. Twelve have a derivation or proof that opens on click, including why two detections are not evidence of motion and why Planet Nine fades as the fourth power of distance.
- Formulas are typeset when the site is built (KaTeX, MIT licence), so no extra script runs in the browser.

Documentation
- Architecture block diagram (`docs/architecture.svg` and `.png`), shown in the README and in `docs/ARCHITECTURE.md`.

## 1.4.0, November 2026

Motion and feel
- Pages rise into place on arrival; the start page arrives in order (words, field list, live preview, globe).
- The navigation underline slides to the current page, and the header stays in reach on wide screens.
- While a field loads, the viewer shows its own outline and a moving progress bar, so nothing jumps when the images arrive.
- Buttons, inputs, table rows and links respond to hover, focus and press. Panels that appear because of something you did (a measurement, an error, the field list) animate in.
- "Link copied" is confirmed with a brief message.
- Blinking between visits stays a hard cut, because that is the measurement. All motion is switched off for people who ask their system for reduced motion.

Identity
- The NASA Space Apps San Diego event logo is shown in the header, the footer and How it works.

## 1.3.0, November 2026

Repository repair
- The repository had 113 unresolved merge conflicts across 33 files, so neither the site nor the API could start. All are resolved to the 1.2 code.
- Removed a second, empty Next.js starter app that had been committed at the top level (`src/`, `public/`, `package.json` and its config files). A host building from the repository root would have deployed that blank page.
- Removed a stale copy of the project zipped inside the repository, and unused starter images.
- Added `.gitattributes` so shell scripts keep Unix line endings on Windows.

Fixes that matter with real archive data
- Finding moving objects compared detections one pair at a time and would have taken minutes to hours on a field with forty visits. It is now vectorised (forty visits in about a second).
- With three or more visits, a track now needs three detections on one line. Two unrelated noise peaks could previously be reported as a mover.
- Cutouts that reach the edge of a detector are padded with empty pixels. Noise estimates, source detection, photometry and difference images now ignore them.
- The completeness measurement injected test stars into the image shared by every request, so another visitor could briefly see them. It now works on a private copy.
- Photometry required the aperture, but not its sky ring, to fit on the image, which biased sources near the edge. The whole ring must fit now.
- Responses can no longer contain NaN, which browsers reject as invalid JSON.
- Blank cells in the archive's answer are handled; a release that returns more images than one query holds is reported.
- An empty answer from JPL is no longer cached for a day.

Fixes in the site
- A slow answer for a field you have already left can no longer overwrite the field you are looking at (viewer, movers, spectrum, Planet Nine).
- Timelapse no longer rewrites the address several times a second, which some browsers block with an error.
- Keyboard shortcuts ignore Ctrl/Cmd combinations and no longer fire twice when a button has focus.
- Dragging a Planet Nine slider sent one request per step and could trip the rate limit; it now waits for the slider to rest.
- Leaving the viewer for the start page no longer leaves the background and its caption pointing at the old field.
- The JPL overlay no longer retries twice a second after a failure, or once per frame during a timelapse.
- The spectrum form checks its input, submits on Enter, and explains an empty result.
- Bad requests (impossible sizes, indexes, albedo of zero, malformed track) get a clear 4xx message in place of a server error.

Content
- How it works now opens with the problem, the solution, who it helps, the novelty, the market with sources, and revenue scenarios with stated assumptions.

## 1.2.0, November 2026

3D, where the third dimension carries information
- Start page: a globe of the whole sky with real stars, constellations, the ecliptic and SPHEREx's deep fields. Turn it and click to choose a position.
- Viewer: a 3D surface view of any visit, with brightness as height.
- Planet Nine: the outer Solar System in 3D with real orbital tilts, the giant planets at today's positions, and one published model of the proposed orbit. The flat drawing remains as an alternative and as the fallback without WebGL.

New in the viewer
- Timelapse: play every visit in date order.
- Click a star to measure it in every visit, with a link to plot the result as a spectrum.
- A "smooth" display option.

Data
- JPL's approximate planetary elements (Table 1) are bundled and used for planet orbits and positions.
- The proposed Planet Nine orbit uses the maximum-likelihood model of Brown & Batygin (2021), labelled as a hypothesis.

Backgrounds
- Each page now faces a different region of the real sky, named at the foot of the page. The viewer faces the field being viewed.
- Long text sits on a quiet backing so stars never run behind words.

## 1.1.0, November 2026

Working
- The website now forwards `/api` to the API itself. The API address is a runtime setting, not part of the built JavaScript, and no CORS setup is needed.
- A status dot in the header says whether searches will return SPHEREx data or the labelled sample.
- Cutouts download four at a time. One release or one image failing no longer loses the whole field.
- A fallback to the sample caused by an archive outage is cached for 90 seconds, not indefinitely.
- When a field has more visits than can be shown, they are sampled evenly in time.
- The viewer works with touch: drag to pan, pinch to zoom. Wheel zoom no longer scrolls the page.
- Links carry the visits, the mode and the movers overlay. "Copy link" and "Save image" added.
- "Show in the viewer" on the Movers page opens the viewer blinking that track.
- Readable errors with a retry button on every page; a 404 page; an error page.
- Rate limiting, security headers, gzip, request ids and non-root containers.
- `run.sh` and `run.bat` start everything with one command.

Looks
- The header and every page fit a phone. Tables scroll inside their own box.
- Small grey text is lighter, for readable contrast.
- The star catalogue behind the page is served from this site in a compact form (about 380 kB compressed). No third-party requests remain.
- Blinking does not start by itself for people who ask their system for reduced motion.

Checks
- 21 backend tests, including the live code path against a stand-in archive.
- A browser smoke test of every page at desktop and phone widths.
- GitHub Actions runs tests, type checks, lint and build.

## 1.0.0, November 2026

First complete version: viewer, movers, spectrum, Planet Nine, methods page.
